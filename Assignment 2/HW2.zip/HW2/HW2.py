## Load Packages
import numpy as np
import matplotlib.pyplot as plt
import time

## Data Input :: Global Parameters
data=np.loadtxt("data.txt",skiprows=13)
m = np.shape(data)[0]       # No of Observations
n = np.shape(data)[1]-1     # No of Features
x = data[:,0:n]
y = data[:,n]
C = 10

## Cost Function
def J(w,b):
    temp = 1 - y * (np.dot(x,w) + b)
    return 0.5*np.dot(w,w) + C*sum(temp[np.where(temp >= 0)])

## Get Batch No From Iteration No
def gb(itr,bs):
    return np.mod(itr,m//bs)

## Mini Batch Gradient Descent Update
def dJ_MBGD(bs,bid,w,b):
    t = gb(bid,bs)
    xtemp = x[(bs*t):bs*(t+1),]
    ytemp = y[(bs*t):bs*(t+1)]
    
    delw = np.zeros(n)
    index = np.where((ytemp * (np.dot(xtemp,w) + b)) < 1)
    delb = C*sum(-y[index])
    for i in range(n):
       delw[i] = C*np.dot(-ytemp[index],np.squeeze(xtemp[index,i]))
    return (w + delw), delb  

## Mini Batch Gradient Descent
def MBGD(eta,eps,bs):
    w = np.zeros(n)
    b = 0
    k = 0
    Jc = []
    D = []
    D.append(0)
    Jc.append(J(w,b))

    while(1):
        up = dJ_MBGD(bs,k,w,b)
        w = w - eta*up[0]
        b = b - eta*up[1]       
        Jc.append(J(w,b))
        k = k + 1
        D.append(0.5*D[k-1]+0.5*(100*abs(Jc[k-1]-Jc[k])/Jc[k-1]))
        if D[k] < eps:
            break
    return Jc,k,w,b 
    
## Batch Gradient Descent
s = time.clock()    
BGD_results = MBGD(1e-9,0.04,m)
t_BGD = time.clock() - s
J_BGD = BGD_results[0]
k_BGD = BGD_results[1]
w_BGD = BGD_results[2]  
b_BGD = BGD_results[3]  
plt.plot(list(range(k_BGD+1)),J_BGD) 


## Stochastic Gradient Descent
s = time.clock()     
SGD_results = MBGD(1e-8,0.0003,1)
t_SGD = time.clock() - s
J_SGD = SGD_results[0]
k_SGD = SGD_results[1]
w_SGD = SGD_results[2]  
b_SGD = SGD_results[3]  
plt.plot(list(range(k_SGD+1)),J_SGD) 

## Mini Batch Gradient Descent
s = time.clock()  
MBGD_results = MBGD(1e-8,0.004,4)
t_MBGD = time.clock() - s
J_MBGD = MBGD_results[0]
k_MBGD = MBGD_results[1]
w_MBGD = MBGD_results[2]  
b_MBGD = MBGD_results[3]  
plt.plot(list(range(k_MBGD+1)),J_MBGD) 

## Plot Graph
plt.xlabel('Number of Iterations ($k$)')   
plt.ylabel('$J(w,b)$ Loss Function')   
plt.title('Comparing Gradient Descent Techniques')
plt.legend(['BGD','SGD','MBGD'])
plt.savefig('F1.eps', format='eps')

## Print Time
print(t_BGD*1000)
print(t_SGD*1000)
print(t_MBGD*1000)

##





