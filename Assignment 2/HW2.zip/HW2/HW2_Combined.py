## Load Packages
import numpy as np
import matplotlib.pyplot as plt

## Data Input :: Global Parameters
data=np.loadtxt("data.txt",skiprows=13)
#np.random.seed(10)
#np.random.shuffle(data)
m = np.shape(data)[0]       # No of Observations
n = np.shape(data)[1]-1     # No of Features
x = data[:,0:n]
y = data[:,n]
##
C = 10
bs = 1     # batch size
bn = m//bs  # batch number 0:bn-1

## Defining Functions
# Cost Function
def J(w,b):
    temp = 1 - y * (np.dot(x,w) + b)
    return 0.5*np.dot(w,w) + C*sum(temp[np.where(temp >= 0)])

### Batch Gradient Descent Update
#def dJ_BGD(w,b):
#    delw = np.zeros(n)
#    index = np.where((y * (np.dot(x,w) + b)) < 1)
#    delb = C*sum(-y[index])
#    for i in range(n):
#       delw[i] = C*np.dot(-y[index],np.squeeze(x[index,i]))
#    return (w + delw), delb
#
### Batch Gradient Descent
#def BGD(eta,eps):
#    w = np.zeros(n)
#    b = 0
#    k = 0   
#    Jc = []
#    Jc.append(J(w,b))
#    
#    while(1):
#        up = dJ_BGD(w,b)
#        w = w - eta*up[0]
#        b = b - eta*up[1]
#        k = k+1
#        Jc.append(J(w,b))
#        delcost = 100*(Jc[k-1]-Jc[k])/Jc[k-1]
#        if delcost < eps:
#            break
#    return Jc,k,w,b

### Stochastic Gradient Descent Update
#def dJ_SGD(xi,yi,w,b):
#    delw = np.zeros(n)
#    delb = 0
#    if (yi * (np.dot(xi,w) + b)) < 1:
#        delb = -yi
#        delw = -yi*xi
#    else:
#        delw = np.zeros(n)
#        delb = 0
#    return (w + C*delw),C*delb
#
### Stochastic Gradient Descent
#def SGD(eta,eps):
#    w = np.zeros(n)
#    b = 0
#    k = 0
#    Jc = []
#    D = []
#    D.append(0)
#    Jc.append(J(w,b))
#    while(1):
#        k = k+1
#        i = np.mod(k,m)
#        up = dJ_SGD(x[i,],y[i],w,b)
#        upw = up[0]
#        upb = up[1]
#        w = w - eta*upw
#        b = b - eta*upb        
#        Jc.append(J(w,b))
#        D.append(0.5*D[k-1]+0.5*(100*abs(Jc[k-1]-Jc[k])/Jc[k-1]))
#        if D[k] < eps:
#            break
#    return Jc,k,w,b    

def gb(itr):
    return np.mod(itr,bn)

## Mini Batch Gradient Descent Update
def dJ_MBGD(bid,w,b):
    t = gb(bid)
    xtemp = x[(bs*t):bs*(t+1),]
    ytemp = y[(bs*t):bs*(t+1)]
    
    delw = np.zeros(n)
    index = np.where((ytemp * (np.dot(xtemp,w) + b)) < 1)
    delb = C*sum(-y[index])
    for i in range(n):
       delw[i] = C*np.dot(-ytemp[index],np.squeeze(xtemp[index,i]))
    return (w + delw), delb  

def MBGD(eta,eps):
    w = np.zeros(n)
    b = 0
    k = 0
    Jc = []
    D = []
    D.append(0)
    Jc.append(J(w,b))

    while(1):
        up = dJ_MBGD(k,w,b)
        w = w - eta*up[0]
        b = b - eta*up[1]       
        Jc.append(J(w,b))
        k = k + 1
        D.append(0.5*D[k-1]+0.5*(100*abs(Jc[k-1]-Jc[k])/Jc[k-1]))
        if D[k] < eps:
            break
    return Jc,k,w,b 
    

# Compare and Plot
## BDG
#BGD_results = BGD(1e-9,0.04)
#w_BGD = BGD_results[2]  
#b_BGD = BGD_results[3]  
#plt.plot(list(range(BGD_results[1]+1)),BGD_results[0]) 
#plt.xlabel('Number of Iterations ($k$)')   
#plt.ylabel('$J(w,b)$ Loss Function')   
#plt.title('Batch Gradient Descent')
## SGD
#SGD_results = SGD(1e-8,0.0003)
#J_SGD = SGD_results[0]
#k_SGD = SGD_results[1]
#w_SGD = SGD_results[2]  
#b_SGD = SGD_results[3]  
#plt.plot(list(range(k_SGD+1)),J_SGD) 
#plt.xlabel('Number of Iterations ($k$)')   
#plt.ylabel('$J(w,b)$ Loss Function')   
#plt.title('Stochastic Gradient Descent')
#MBGD
MBGD_results = MBGD(1e-8,0.004)
w_MBGD = MBGD_results[2]  
b_MBGD = MBGD_results[3]  
plt.plot(list(range(MBGD_results[1]+1)),MBGD_results[0]) 
plt.xlabel('Number of Iterations ($k$)')   
plt.ylabel('$J(w,b)$ Loss Function')   
plt.title('Mini Batch Gradient Descent')


        









