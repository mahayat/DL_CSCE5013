## Load Packages
import numpy as np
import matplotlib.pyplot as plt
# from sklearn import svm

## Data Input :: Global Parameters
data=np.loadtxt("data.txt",skiprows=13)
#data = data
#np.random.shuffle(data)
m = np.shape(data)[0]       # No of Observations
n = np.shape(data)[1]-1     # No of Features
x = data[:,0:n]
y = data[:,n]

C = 10
bs = 4    # batch size
bn = m//bs  # no of batches 0:bn-1

##
def gb(itr):
    return np.mod(itr,bn)

## Cost Function
def J(w,b):
    temp = 1 - y * (np.dot(x,w) + b)
    return 0.5*np.dot(w,w) + C*sum(temp[np.where(temp >= 0)])

## Batch Gradient Descent Update
def dJ_BGD(bid,w,b):
    t = gb(bid)
    xtemp = x[(bs*t):bs*(t+1),]
    ytemp = y[(bs*t):bs*(t+1)]
    
    delw = np.zeros(n)
    index = np.where((ytemp * (np.dot(xtemp,w) + b)) < 1)
    delb = C*sum(-y[index])
    for i in range(n):
       delw[i] = C*np.dot(-ytemp[index],np.squeeze(xtemp[index,i]))
    return (w + delw), delb

## Simulation Parameters
w = np.zeros(n)
b = 0
eta = 1e-8
eps = 0.004

## Stochastic Gradient Descent 
k = 0
Jc = []
D = []
D.append(0)
Jc.append(J(w,b))

#
while(1):
    up = dJ_BGD(k,w,b)
    upw = up[0]
    upb = up[1]
    w = w - eta*upw
    b = b - eta*upb        
    Jc.append(J(w,b))
    k = k + 1
    D.append(0.5*D[k-1]+0.5*(100*abs(Jc[k-1]-Jc[k])/Jc[k-1]))
    if D[k] < eps:
        break
#    
### Compare and Plot
##y_hat = np.sign(np.dot(x,w)+b)   
plt.plot(Jc) 
