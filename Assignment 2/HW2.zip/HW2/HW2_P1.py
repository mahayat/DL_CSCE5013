## Load Packages
import numpy as np
import matplotlib.pyplot as plt
# from sklearn import svm

## Data Input :: Global Parameters
data=np.loadtxt("data.txt",skiprows=13)
m = np.shape(data)[0]       # No of Observations
n = np.shape(data)[1]-1     # No of Features
x = data[:,0:n]
y = data[:,n]

C = 10
## Defining Functions

# Cost Function
def J(w,b):
    temp = 1 - y * (np.dot(x,w) + b)
    return 0.5*np.dot(w,w) + C*sum(temp[np.where(temp >= 0)])

# Batch Gradient Descent Update
def dJdwdb(w,b):
    delw = np.zeros(n)
    index = np.where((y * (np.dot(x,w) + b)) < 1)
    delb = C*sum(-y[index])
    for i in range(n):
       delw[i] = C*np.dot(-y[index],np.squeeze(x[index,i]))
    return (w + delw), delb

## Simulation Parameters
w = np.zeros(n)
b = 0
eta = 1e-9
eps = 0.04

## Batch Gradient Descent 
k = 0
Jc = []
Jc.append(J(w,b))
while(1):
    up = dJdwdb(w,b)
    upw = up[0]
    upb = up[1]
    w = w - eta*upw
    b = b - eta*upb
    k = k+1
    Jc.append(J(w,b))
    delcost = 100*(Jc[k-1]-Jc[k])/Jc[k-1]
    if delcost < eps:
        break
    
## Compare and Plot
#y_hat = np.sign(np.dot(x,w)+b)   
plt.plot(Jc) 
#sum(y == 1)
#sum(y == -1)
#sum(y_hat == 1)
#sum(y_hat == -1)

        









