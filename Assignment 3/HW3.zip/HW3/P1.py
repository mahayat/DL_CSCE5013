## Load Packages
import numpy as np
import matplotlib.pyplot as plt

## Float to Integer (0:9) 
def flag(Y):
    out = np.zeros((np.shape(Y)[0],10))
    Y = Y.astype(int)
    for i in np.arange(np.shape(Y)[0]):
        out[i,Y[i]-1] = 1
    return out

## Sigmoid
def sig(x):
    out = np.zeros(np.shape(x))
    for i in np.arange(np.shape(x)[0]):
        for j in np.arange(np.shape(x)[1]):
            out[i,j] = 1/(1+np.exp(-x[i,j]))
    return out

## Differential Sigmoid
def dsig(z):
    out = np.zeros(np.shape(z))
    for i in np.arange(np.shape(z)[0]):
        for j in np.arange(np.shape(z)[1]):
            temp = 1/(1+np.exp(-z[i,j]))
            out[i,j] = temp*(1-temp)
    return out

## Forward Propagation
def fprop(X,W1,W2):
    X = np.insert(X, 0, 1, axis=1)
    Z1 = X@W1.T 
    H = sig(Z1)
    H = np.insert(H, 0, 1, axis=1)
    Z2 = H@W2.T
    Y_prob = sig(Z2)
    return Y_prob

## Class Prediction from Probabilities
def pred(Y_prob):
    return np.argmax(Y_prob,1)+1
    
## Performance Evaluation (From Classes)
def accu(Y_class,Y_class_hat):
    return 100*np.sum(Y_class == Y_class_hat)/Y_class.shape[0]     

## Loss Function 
def J(Y,Y_hat,w1,w2,lam):
    m = Y.shape[0]
    ST = (lam/(2*m))*(np.sum(np.square(w1)[:,1:])+np.sum(np.square(w2)[:,1:]))    
    FT = 0
    for i in np.arange(m):
        for k in np.arange(10):
            FT = FT - Y[i,k]*np.log(Y_hat[i,k]) - (1-Y[i,k])*np.log(1-Y_hat[i,k])            
    return FT/m+ST

## Backpropagation
def bprop(X,Y,Y_hat,W1,W2,lamb):
    m = X.shape[0]
    beta2 = Y_hat - Y    
    X = np.insert(X, 0, 1, axis=1)
    Z1 = X@W1.T 
    H = sig(Z1)
    H = np.insert(H, 0, 1, axis=1)    
    beta1 = (beta2@W2[:,1:])*dsig(Z1)
    dJW2 = beta2.T@H
    dJW1 = beta1.T@X
    W2[::,0] = 0
    W1[::,0] = 0    
    dW2 = (dJW2/m)+(lamb/m)*W2
    dW1 = (dJW1/m)+(lamb/m)*W1
    return dW1,dW2
          
## Load Data
X = np.loadtxt('X.csv',delimiter=",")
Y_class = np.loadtxt('Y.csv',delimiter=",").astype(int)
Y = flag(Y_class)

## Checking Forward Propagation, Prediction and Cost Function
W1_0 = np.loadtxt('W1.csv',delimiter=",")
W2_0 = np.loadtxt('W2.csv',delimiter=",")
Y0_prob = fprop(X,W1_0,W2_0) # Probabilities after fprop
Y0_class = pred(Y0_prob) # Prediction from Probabilities
acc_debug = accu(Y_class,Y0_class) # Accuracy (True Detection)
cost_debug = J(Y,Y0_prob,W1_0,W2_0,3) # Cost

## ANN Initialize
itr = 500
rpar = 3
eta = 0.2
W1 = np.loadtxt('initial_W1.csv',delimiter=",")
W2 = np.loadtxt('initial_W2.csv',delimiter=",")
fcost = np.ones(itr)
facc = np.ones(itr)

## Epoch
for i in np.arange(itr):
    print('Iteration #', i)
    Y_hat = fprop(X,W1,W2) # Probabilities after fprop
    Y_class_hat = pred(Y_hat) # Prediction from Probabilities
    facc[i] = accu(Y_class,Y_class_hat) 
    fcost[i] = J(Y,Y_hat,W1,W2,rpar)
    dW1,dW2 = bprop(X,Y,Y_hat,W1,W2,rpar) # Backpropagation
    W2 = W2 - eta*dW2 # Update W2
    W1 = W1 - eta*dW1 # Update W1 
    
## Plot Cost
L = plt.figure(1)
plt.plot(fcost)
plt.xlabel('Number of Iterations')   
plt.ylabel('Loss Function ($J$)')   
plt.title('Loss Function ($J$) vs Number of Iterations') 
plt.grid(b=None, axis='both')

## Plot Accuracy
A = plt.figure(2)
plt.plot(facc) 
plt.xlabel('Number of Iterations')   
plt.ylabel('Accuracy')   
plt.title('Accuracy vs Number of Iterations') 
plt.grid(b=None, axis='both')